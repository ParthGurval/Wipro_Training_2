package com.wipro.security.jwt;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtSpringBootAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwtSpringBootAppApplication.class, args);
	}

}
