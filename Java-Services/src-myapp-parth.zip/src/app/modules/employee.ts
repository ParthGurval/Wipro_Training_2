

export class Employee {
    id: number = 0;
    ename: string = '';
    age: number = 0;
    salary: number = 0;
    doj: Date = new Date();
    department: string = '';
    experience: number = 0;
  }