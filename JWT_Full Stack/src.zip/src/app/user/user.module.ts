import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from '../login/login.component'; // Import the LoginComponent
import { SignupComponent } from '../signup/signup.component'; // Import the SignupComponent
import { UserService } from './user.service'; // Import the UserService
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    LoginComponent, // Declare the LoginComponent
    SignupComponent  // Declare the SignupComponent
  ],
  imports: [
    CommonModule,
    FormsModule
  ],
  providers: [
    UserService // Provide the UserService for dependency injection
  ],
  exports: [
    LoginComponent,  // Export the LoginComponent if needed elsewhere
    SignupComponent  // Export the SignupComponent if needed elsewhere
  ]
})
export class UserModule { }
