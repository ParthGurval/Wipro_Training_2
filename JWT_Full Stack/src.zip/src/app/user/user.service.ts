import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  // constructor() { }

  private baseUrl = 'http://localhost:8282';  // Your backend API URL

  constructor(private http: HttpClient) {}

  login(username: string, password: string): Observable<any> {
    return this.http.post(`${this.baseUrl}/user/loginUser`, { username, password });
  }

  signup(user: { username: string, password: string, email: string }): Observable<any> {
    return this.http.post(`${this.baseUrl}/user/saveUser`, user);
  }
}
