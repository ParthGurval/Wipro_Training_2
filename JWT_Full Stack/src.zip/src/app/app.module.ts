import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http'; // Import HttpClientModule
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { UserModule } from './user/user.module'; // Import User module
import { JwtInterceptor } from './interceptors/jwt.interceptor'; // Import JWT Interceptor

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent // Keep only the components that are directly part of AppModule
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule, // Add HttpClientModule for making HTTP requests
    UserModule // Add UserModule for user-related components and services
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: JwtInterceptor,
      multi: true // Use JwtInterceptor as an HTTP interceptor
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
