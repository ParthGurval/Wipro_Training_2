import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user/user.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent {

  username: string = '';
  password: string = '';
  email: string = '';

  constructor(private userService: UserService, private router: Router) {}

  signup() {
    this.userService.signup({username: this.username, password: this.password, email: this.email}).subscribe(() => {
      this.userService.login(this.username, this.password).subscribe(response => {
        localStorage.setItem('token', response.token);
        this.router.navigate(['/home']);
      });
    });
  }
}
